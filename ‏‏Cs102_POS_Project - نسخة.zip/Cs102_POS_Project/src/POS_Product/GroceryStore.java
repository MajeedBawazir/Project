package POS_Product;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class GroceryStore implements MyGroceryStore{

    private List<Product> products;

    public GroceryStore() {
        products = new LinkedList<>();
    }
    @Override
    public void addProduct(Product product) {
        products.add(product);
    }
    @Override
    public void removeProduct(Product product) {
        products.remove(product);
    }
    //search product by name
    
//    private Product searchProduct(String name) {
//        for (Product product : products) {
//            if (product.getName().equalsIgnoreCase(name)) {
//                return product;
//            }
//        }
//        return null;
//    }

    @Override
    public Product searchProductID(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null;
    }

    @Override
    public boolean updateLevel(int id, int qnty) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId() == id) {
                System.out.println("product found and its level is :" + products.get(i).getLevel());
                int q = products.get(i).getLevel();
                if (qnty <= q) {
                    q -= qnty;
                    products.get(i).setLevel(q);
                    System.out.println("Level updated succesfully");
                    return true;
                }
            }

        }

        System.out.println("There is not enough level");

        return false;
    }

    @Override
    public List<Product> getProducts() {
        return products;
    }
}
