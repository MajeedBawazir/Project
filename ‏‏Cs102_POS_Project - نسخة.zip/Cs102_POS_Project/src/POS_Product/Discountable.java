package POS_Product;


public interface Discountable {
    
    public double calculateDiscount();
}