package POS_Product;

import java.util.ArrayList;

public class Cart implements MyCart{
    private ArrayList<Product> items;
    private ArrayList<Integer> quantities;

    public Cart(){
        items = new ArrayList<Product>();
        quantities = new ArrayList<Integer>();
    }

    @Override
    public void addItem(Product product, int quantity) {
        items.add(product);
        quantities.add(quantity);
    }
    @Override
    public ArrayList<Product> getItems() {
        return items;
    }
    @Override
    public  ArrayList<Integer> getQuantities() {
        return quantities;
    }
    
    @Override
    public void mostFrequentWord() {

        int freq = 0;

        String res="";

        for (int i = 0; i < items.size(); i++) {
            int count = 1;
            for (int j = i + 1; j < items.size(); j++) {
                if (items.get(j).getName().equals(items.get(i).getName())) {
                    count++;
                }
            }
            
            if (count >= freq) {
                res = items.get(i).getName();
                freq = count;
            }
        }

        System.out.println("The word that occurs most is : " + res);

        System.out.println("No of times: " + freq);
    }
}

