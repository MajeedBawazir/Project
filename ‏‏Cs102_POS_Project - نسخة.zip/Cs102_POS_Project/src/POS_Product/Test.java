package POS_Product;

import POS_Product.Sale;
import POS_Product.Product;
import POS_Product.GroceryStore;
import POS_Product.Cart;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import java.util.Scanner;


public class Test{

    static GroceryStore store = new GroceryStore();
    static Cart cart = new Cart();
    static Sale sale;
    static ArrayList<Sale> sales = new ArrayList<>();

    public static void main(String[] args) throws IOException {

        Scanner input = new Scanner(new File("products.txt"));
        String line = null;

        while (input.hasNext()) {
            line = input.nextLine();
            //  System.out.println(line);
            String[] tokens = line.split(",");
            int id = Integer.parseInt(tokens[0]);

            String name = tokens[1];
            double price = Double.parseDouble(tokens[2]);
            int lvl = Integer.parseInt(tokens[3]);

            Product p = new Product(id, name, price, lvl);
            //add product to store
            store.addProduct(new Product(id, name, price, lvl));
        }

        //print all available product
        for (Product p : store.getProducts()) {
            System.out.println(p.toString());
        }
        input.close();

        Scanner inp = new Scanner(System.in);

        // Create a sample sale and add it to the sales list
        int op = 0;
        while (op != 7) {
            System.out.println("\n");
            System.out.println("1-purchase product");
            System.out.println("2-Total Revenue");
            System.out.println("3-dispaly inventory level ");
            System.out.println("4-Get total price recursivly  ");
            System.out.println("5-save to file ");
            System.out.println("6-Most frequent");
            System.out.println("7-Exit ");
            System.out.print("Enter your option: ");
            op = inp.nextInt();
            try{
            switch (op) {
                case 1:
                    //  store.getProducts();
                   
                    
                    System.out.print("Enter product id : ");
                    int id = inp.nextInt();

                    System.out.println("Enter quantity");
                     int qnt= inp.nextInt();
                    
                   
                    if (store.updateLevel(id, qnt)) {
                        Product p = store.searchProductID(id);
                        cart.addItem(p, qnt);
                        sale = new Sale("Majeed", cart);
                        System.out.println("======================");
                        System.out.println(sale.getItems());
                    }
                    break;

                case 2:

                    System.out.println("TOTAL PRICE = " + sale.getTotalPrice());
                    System.out.println("Total Discount = " + sale.getDiscount());
                    System.out.println("total price after discount = " + (sale.getTotalPrice() - sale.getDiscount()));
                    break;
                case 3:
                    for (Product p : store.getProducts()) {
                        System.out.println(p.toString());
                    }

                    break;
                case 4:
                     
                    System.out.println("totla price = "+sale.getTotalPriceRec(0));

                    break;

                case 5:
                    SaveTofile(store);
                    break;

                case 6:
                    cart.mostFrequentWord();
                    break;
                case 7:
                    break;
                default:
                    System.out.println("error selection");

            }
            }
             catch(Exception e)
                    {
                        System.out.println("*** Make sure you enter an integer number ***");
                        System.out.println("*** Make sure you to choose First one purchase product ***");
                        break;
                    }

        }

        // Generate a sales report
        // SalesReportGenerator.generateSalesReport(sales);
    }

    public static void SaveTofile(GroceryStore store) {

        try {
            PrintWriter PW = new PrintWriter(new File("output_data.txt"));

            for (Product pr : store.getProducts()) {

                PW.println(pr.getId() + "," + pr.getName() + "," + pr.getPrice()+"," + pr.getLevel());

            }

            PW.close();

            System.out.println("save all product information into data.txt");
        } catch (IOException ex) {
            System.out.println(ex.toString());
        }
    }
}

