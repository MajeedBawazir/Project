package POS_Product;


import java.util.ArrayList;

public interface MySale {

    double totalPrice();

    public double getTotalPriceRec(int n);

    public double makeDiscount();

    public double getTotalPrice();

    public double getDiscount();

    public ArrayList<Product> getItems();

    public ArrayList<Integer> getQuantities();
}
