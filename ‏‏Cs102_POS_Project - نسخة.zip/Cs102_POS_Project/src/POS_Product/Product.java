package POS_Product;



import POS_Product.Discountable;
import java.util.*;

public class Product implements Discountable{
    private int id;
    private String name;
    private double price;
    private int level;

    public Product(int id,String name, double price, int level) {
        this.id=id;
        this.name = name;
        this.price = price;
        this.level = level;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getLevel() {
        return level;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    @Override
    public double calculateDiscount() {
        return price * 0.2;
    }

    @Override
    public String toString() {
        return "Product{" + "id=" + id + ", name=" + name + ", price=" + price + ", level=" + level + '}';
    }

    
    
   
    
}
