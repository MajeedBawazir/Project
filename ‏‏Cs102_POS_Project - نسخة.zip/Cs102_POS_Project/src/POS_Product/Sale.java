package POS_Product;


import POS_Product.Product;
import POS_Product.MySale;
import POS_Product.Cart;
import java.util.ArrayList;
import java.util.List;


public class Sale implements MySale{
    private String customerName;
    private double total;
    private double discount;
    private Cart cart;
    public Sale(String customerName, Cart cart) {
        this.customerName = customerName;
        this.cart = cart;
        this.total=totalPrice() ;
        this.discount=makeDiscount();
    }
    

    @Override
    public double totalPrice() {
         total= 0;
        for (int i = 0; i < cart.getItems().size(); i++) {
            Product product = cart.getItems().get(i);
            int qnty = cart.getQuantities().get(i);
            total += product.getPrice() * qnty;
        }
        return total;
    }
    
    //recursion
    @Override
    public double getTotalPriceRec(int n)  {
       
        if(n==cart.getItems().size())  return 0;
        
        else
              return cart.getItems().get(n).getPrice()*cart.getQuantities().get(n)+getTotalPriceRec(++n) ;
       
    }
    
    
    
    //compute total discount for all purshased items 
    //and return total price - discount
    @Override
    public double  makeDiscount() {
        discount= 0;
        for (int i = 0; i < cart.getItems().size(); i++) {
            Product product = cart.getItems().get(i);
            int quantity = cart.getQuantities().get(i);
            discount += product.calculateDiscount() * quantity;
        }
        return discount;
    }

    @Override
    public double getTotalPrice() {
        return total;
    }
    @Override
    public double getDiscount() {
        return discount;
    }
    @Override
    public ArrayList<Product> getItems() {
        return cart.getItems();
    }
    @Override
    public ArrayList<Integer> getQuantities() {
        return cart.getQuantities();
    }

    @Override
    public String toString() {
        return "Sale{" + "customerName=" + customerName + ", total=" + total + ", discount=" + discount + '}';
    }
    
}