package POS_Product;



import java.util.ArrayList;


public interface MyCart {
   

 public void addItem(Product product, int quantity);

 public ArrayList<Product> getItems();

 public ArrayList<Integer> getQuantities();

 public void mostFrequentWord();
}