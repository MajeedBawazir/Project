package POS_Product;


import java.util.List;

public interface MyGroceryStore {

    public void addProduct(Product product);

    public void removeProduct(Product product);

    public Product searchProductID(int id);

    public boolean updateLevel(int id, int qnty);

    List<Product> getProducts();
}
